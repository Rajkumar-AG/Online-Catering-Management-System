<div class="footer">
            <p>© Online Catering Management System.</p>
        </div>